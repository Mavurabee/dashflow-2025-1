export type  GraphsJson ={
    statusName: string;
    count: number;
}