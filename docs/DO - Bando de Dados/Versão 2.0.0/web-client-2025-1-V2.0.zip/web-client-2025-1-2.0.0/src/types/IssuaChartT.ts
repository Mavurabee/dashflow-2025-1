export type IssueChartT={
    Bug :number;
    Enhancement :number;
    Question :number;
}