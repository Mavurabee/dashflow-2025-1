<script setup lang="ts">


</script>

<template>
    <div class="profile">
        <h1>Profile</h1>
    </div>
</template>

<style lang="scss" scoped>
</style>