<script setup lang="ts">


</script>

<template>
    <div class="home">
        <h1>Home</h1>
    </div>
</template>

<style lang="scss" scoped>
.home{
    background-color: var(--color-secondary);
}
</style>