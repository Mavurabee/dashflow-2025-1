package com.manolito.dashflow.handlers.tools;

public interface ToolHandler {
    void handleRequest(String endpoint);
}
