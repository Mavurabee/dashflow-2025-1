package com.manolito.dashflow.service;

public interface EndpointService {
    public void handleRequest(String requestUrl);
}
