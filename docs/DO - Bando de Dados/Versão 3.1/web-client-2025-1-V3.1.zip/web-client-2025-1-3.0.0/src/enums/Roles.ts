export enum Roles {
    ADMIN = 'Admin',
    MANAGER = 'Manager',
    OPERATOR = 'Operator'
}
