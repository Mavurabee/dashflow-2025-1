export type chartDataObj = {
    created:number,
    done:number,
  }