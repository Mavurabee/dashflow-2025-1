export type MultiOptions = {
    value: string;
    label: string
}