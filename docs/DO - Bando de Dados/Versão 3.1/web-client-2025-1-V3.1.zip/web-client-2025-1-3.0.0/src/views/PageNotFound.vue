<style scoped lang="css">
body { 
  color: #fff;
  font-size: 100%;
  line-height: 1.5;
}


p {
  font-size: 2em;
  text-align: center;
  font-weight: 100;
}

h1 {
  text-align: center;
  font-size: 15em;
  font-weight: 100;
}
</style>
<template>
<body>    
    <h1>404</h1>
    <p>Oops! Page not found.</p>
</body>  
</template>