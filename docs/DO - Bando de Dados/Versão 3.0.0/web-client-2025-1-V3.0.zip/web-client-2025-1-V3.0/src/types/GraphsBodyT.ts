export type fetchGraphsBody={
    userIdRef:number;
    startDate:string;
    endDate:string;
}