export type IssueChartT={
    type :string;
    count :number;
}