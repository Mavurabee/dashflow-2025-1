export type cardsByPeriodResponse = {
    createdTaskCount:number,
    completedTaskCount:number
}