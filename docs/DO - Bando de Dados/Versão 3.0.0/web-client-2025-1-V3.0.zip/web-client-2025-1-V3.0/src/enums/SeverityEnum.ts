export enum SeverityEnum {
    CRITICAL = 'CRITICAL',
    IMPORTANT = 'IMPORTANT',
    NORMAL = 'NORMAL',
    MINOR = 'MINOR',
    WHISHLIST = 'WHISHLIST',
}