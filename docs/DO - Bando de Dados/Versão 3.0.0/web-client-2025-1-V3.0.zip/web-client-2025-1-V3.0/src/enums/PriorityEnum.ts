export enum PriorityEnum {
    ALL = 'ALL',
    HIGH = 'HIGH',
    NORMAL = 'NORMAL',
    LOW = 'LOW'
}
