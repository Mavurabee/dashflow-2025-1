export enum Tools {
    TAIGA = 'Taiga',
    JIRA = 'Jira',
    TRELLO = 'Trello'
}
